import React from 'react';
import { TextInput, StyleSheet } from 'react-native';
import { colors } from '../styles/colors';

export default function CustomInput(props) {
  return (
    <TextInput
      style={styles.input}
      placeholderTextColor={colors.textLight}
      {...props}
    />
  );
}

const styles = StyleSheet.create({
  input: {
    width: '100%',
    height: 50,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontSize: 16,
    color: colors.textDark,
    marginBottom: 12,
  },
});