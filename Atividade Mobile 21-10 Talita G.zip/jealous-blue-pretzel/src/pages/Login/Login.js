import React, { useState } from 'react';
import { View, Text, Alert } from 'react-native';
import CustomInput from '../../../src/components/CustomInput';
import CustomButton from '../../../src/components/CustomButton';
import { styles } from './Login.styles';

export default function Login({ onLoginSuccess }) {
  const [usuario, setUsuario] = useState('');
  const [senha, setSenha] = useState('');

  const handleLogin = () => {
    if (!usuario.trim()) {
      Alert.alert('Atenção', 'Informe o usuário.');
      return;
    }
    if (!senha.trim()) {
      Alert.alert('Atenção', 'Informe a senha.');
      return;
    }

    // Credenciais padronizadas conforme o documento
    if (usuario === 'aluno' && senha === '123456') {
      onLoginSuccess();
    } else {
      Alert.alert('Erro', 'Usuário ou senha inválidos.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>As Efigênias</Text>
      <Text style={styles.subtitle}>faça login para continuar</Text>

      <CustomInput
        placeholder="Usuário"
        value={usuario}
        onChangeText={setUsuario}
        autoCapitalize="none"
      />

      <CustomInput
        placeholder="Senha"
        value={senha}
        onChangeText={setSenha}
        secureTextEntry={true}
      />

      <CustomButton title="Entrar" onPress={handleLogin} />
    </View>
  );
}