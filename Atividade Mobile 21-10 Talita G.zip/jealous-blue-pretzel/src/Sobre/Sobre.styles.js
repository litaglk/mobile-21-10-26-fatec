import { StyleSheet } from 'react-native';
import { colors } from '../styles/colors';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 24,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.secondary,
    marginBottom: 12,
  },
  subheading: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
    marginTop: 16,
    marginBottom: 4,
  },
  text: {
    fontSize: 16,
    color: colors.textDark,
    lineHeight: 22,
  },
  version: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 24,
    fontStyle: 'italic',
  },
  buttonContainer: {
    marginTop: 24,
  },
});