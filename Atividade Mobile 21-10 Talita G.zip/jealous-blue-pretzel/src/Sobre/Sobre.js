import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import Toolbar from '../components/Toolbar';
import CustomButton from '../components/CustomButton';
import { styles } from './Sobre.styles';

export default function Sobre({ onNavigate }) {
  return (
    <View style={styles.container}>
      <Toolbar title="Sobre" showBack={true} onBackPress={() => onNavigate('Home')} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.heading}>As Efigênias</Text>
        <Text style={styles.text}>
          juntas, construímos mais do que casas: criamos recomeços.
        </Text>
        
        <Text style={styles.subheading}>reformas</Text>
        <Text style={styles.text}>+120 casas reformadas.</Text>

        <Text style={styles.subheading}>impacto</Text>
        <Text style={styles.text}>+450 famílias impactadas.</Text>

        <Text style={styles.subheading}>voluntariado</Text>
        <Text style={styles.text}>+300 voluntárias ativos</Text>

        <Text style={styles.version}>versão da aplicação: 1.0</Text>

        <View style={styles.buttonContainer}>
          <CustomButton title="Voltar para Home" onPress={() => onNavigate('Home')} />
        </View>
      </ScrollView>
    </View>
  );
}