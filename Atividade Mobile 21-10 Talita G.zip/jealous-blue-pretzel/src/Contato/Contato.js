import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import Toolbar from '../components/Toolbar';
import CustomButton from '../components/CustomButton';
import { styles } from './Contato.styles';

export default function Contato({ onNavigate }) {
  return (
    <View style={styles.container}>
      <Toolbar title="Contato" showBack={true} onBackPress={() => onNavigate('Home')} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.heading}>fale com a gente!</Text>
        
        <View style={styles.card}>
          <Text style={styles.label}>ONG:</Text>
          <Text style={styles.value}>As Efigênias</Text>

          <Text style={styles.label}>Telefone:</Text>
          <Text style={styles.value}>(11) 99913-9989</Text>

          <Text style={styles.label}>E-mail:</Text>
          <Text style={styles.value}>asefigenias@ong.com</Text>

          <Text style={styles.label}>Endereço:</Text>
          <Text style={styles.value}>Rua Olga Benario, 100 - São Paulo, SP</Text>
        </View>

        <CustomButton title="Voltar para Home" onPress={() => onNavigate('Home')} />
      </ScrollView>
    </View>
  );
}