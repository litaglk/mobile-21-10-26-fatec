import React from 'react';
import { View, Text } from 'react-native';
import Toolbar from '../components/Toolbar';
import CustomButton from '../components/CustomButton';
import { styles } from './Home.styles';

export default function Home({ onNavigate }) {
  return (
    <View style={styles.container}>
      <Toolbar title="Home" />
      <View style={styles.content}>
        <Text style={styles.welcome}>bem-vindas ao aplicativo das Efigênias!</Text>
        <Text style={styles.description}>
          Aqui você pode navegar pelas nossas seções para conhecer mais sobre as nossas iniciativas.
        </Text>

        <CustomButton title="conheça nossa história" onPress={() => onNavigate('Sobre')} />
        <CustomButton title="entre em contato com a gente" onPress={() => onNavigate('Contato')} type="secondary" />
      </View>
    </View>
  );
}

