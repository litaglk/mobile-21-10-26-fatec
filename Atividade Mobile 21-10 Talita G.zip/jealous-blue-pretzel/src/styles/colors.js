export const colors = {
  primary: '#8b0000',
  secondary: '#8b0000',
  background: '#FFE176',
  white: '#ffe176',
  textDark: '#8b0000',
  textLight: '#8b0000',
  error: '#E76F51',
  border: '#8b0000',
};