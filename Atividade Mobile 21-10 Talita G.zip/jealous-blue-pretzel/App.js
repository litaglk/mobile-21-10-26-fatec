import React, { useState } from 'react';
import { SafeAreaView, StatusBar, StyleSheet } from 'react-native';
import Login from './src/pages/Login/Login';
import Home from './src/Home/Home';
import Sobre from './src/Sobre/Sobre';
import Contato from './src/Contato/Contato';
import {colors} from './src/styles/colors';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('Login');

  const renderScreen = () => {
    switch (currentScreen) {
      case 'Login':
        return <Login onLoginSuccess={() => setCurrentScreen('Home')} />;
      case 'Home':
        return <Home onNavigate={(screen) => setCurrentScreen(screen)} />;
      case 'Sobre':
        return <Sobre onNavigate={(screen) => setCurrentScreen(screen)} />;
      case 'Contato':
        return <Contato onNavigate={(screen) => setCurrentScreen(screen)} />;
      default:
        return <Login onLoginSuccess={() => setCurrentScreen('Home')} />;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />
      {renderScreen()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary,
  },
});